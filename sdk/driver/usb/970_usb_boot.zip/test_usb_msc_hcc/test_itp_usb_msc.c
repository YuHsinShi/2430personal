﻿/*
 * Copyright (c) 2011 ITE Tech. Inc. All Rights Reserved.
 */
/** @file
 * PAL USB Mass Storage Class related code.
 *
 * @author Irene Lin
 * @version 1.0
 */
#include <string.h>
#include <stdio.h>
#include "ite/itp.h"
#include "ite/ite_msc.h"
#include "test_usb_msc.h"

#define RETRY_NUM       20

static void MscConnect(ITPUsb* itpusb)
{
    if(USB_DEVICE_MSC(itpusb->type))
    {
        MscLunStatus mscStatus;
        int lun, res, retry = RETRY_NUM;

        printf(" USB%d: MSC is inserted!! \n", itpusb->index);

        do {
#if 1  // for card reader
            for (lun = 0; lun < 4; lun++) {
                if ((res = iteMscGetStatus(itpusb->ctxt, lun)) == 0)
                    break;
            }
#else
            res = iteMscGetStatus(itpusb->ctxt, lun);
#endif
        } while (res && --retry);

        if (res == 0)
        {
            mscStatus.lun = (itpusb->index == 0) ? lun : (8 + lun);
            mscStatus.inserted = 1;
            mscStatus.ctxt = itpusb->ctxt;
            mscStatus.type = itpusb->type;
            printf(" %d: active \n", mscStatus.lun);

            TestFunc(&mscStatus);
        }
    }
}

