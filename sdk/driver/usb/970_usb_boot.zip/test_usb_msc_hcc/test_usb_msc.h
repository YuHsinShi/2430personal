﻿#ifndef TEST_USB_MSC_H
#define TEST_USB_MSC_H

typedef struct
{
    int     lun;
    int     inserted;
    void*   ctxt;
    int     type;
} MscLunStatus;


#endif
