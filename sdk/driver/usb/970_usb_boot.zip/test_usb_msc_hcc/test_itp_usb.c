﻿/*
 * Copyright (c) 2011 ITE Tech. Inc. All Rights Reserved.
 */
/** @file
 * PAL USB functions.
 *
 * @author Irene Lin
 * @version 1.0
 */
#include <pthread.h>
#include "ite/ite_usbex.h"

#include "test_itp_usb_host.c"



int UsbInit(void)
{
    int res;
	int usb_en = 0;

#if defined(CFG_USB0_ENABLE)
	usb_en |= (1 << 0);
#endif
#if defined(CFG_USB1_ENABLE)
	usb_en |= (1 << 1);
#endif
    res = mmpUsbExInitialize(usb_en);
    if(res)
        return res;

#if defined(CFG_UAS_ENABLE)
    res = iteUasDriverRegister();
    if(res)
        return res;
#endif

#if defined(CFG_MSC_ENABLE)
    res = iteMscDriverRegister();
    if(res)
        return res;
#endif

    UsbHostDetectHandler(NULL);
}




