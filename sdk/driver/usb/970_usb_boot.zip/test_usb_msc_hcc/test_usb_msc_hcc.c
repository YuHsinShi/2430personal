﻿#include <pthread.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <string.h>
#include "openrtos/FreeRTOS.h"
#include "openrtos/queue.h"
#include "fat/fat.h"
#include "ite/itp.h"
#include "ite/ite_usbex.h"
#include "test_usb_msc.h"


#define LOOP_NUM    8*2
#define BUF_SIZE    128*1024//512*1024

static uint8_t*  pattern[16];
static uint8_t*  readBuf[16];
static uint8_t  filePath[16][64] = {0};

#define FILE    FN_FILE
#define fopen   f_open
#define fclose  f_close
//#define err()  do { vTaskSuspendAll(); while(1); } while(0)
#define err()   do { goto end; }while(0)

int ReadWriteTest(int idx)
{
    FILE* file = NULL;
    int i, res;
    uint32_t diff;

    printf("\n\nT%d: start read/write test............\n", idx);

    pattern[idx] = malloc(BUF_SIZE);
    readBuf[idx] = malloc(BUF_SIZE);

    for(i=0; i<BUF_SIZE; i++) /** fill pattern */
        pattern[idx][i] = (i+idx) % 0x100;

    /***************/
    /* Write       */
    /***************/
    file = fopen(filePath[idx], "w");
    if(!file)
    {
        printf("T%d: open %s for write fail! \n\n", idx, filePath[idx]);
        err();
    }
    printf("T%d: write data.... \n", idx);
    for(i=0; i<LOOP_NUM; i++)
    {
        printf("T%d:@\n", idx);
        res = f_write(pattern[idx], 1, BUF_SIZE, file);
        if(res != BUF_SIZE)
        {
            printf("T%d: real write size 0x%X != write size 0x%X \n", idx, res, BUF_SIZE);
            goto end;
        }
    }
    res = 0;
    f_flush(file);
    printf("T%d: Write finish!\n", idx);
    if(file)
    {
        res=fclose(file);
        file = NULL;
        if(res) goto end;
    }

    /*******************/
    /* Read & Compare  */
    /*******************/
    printf("T%d: compare data! \n", idx);
    file = fopen(filePath[idx], "r");
    if(!file)
    {
        printf("T%d: open %s for read fail! \n\n", idx, filePath[idx]);
        goto end;
    }
    printf("T%d: read data from card.. \n", idx);
    for(i=0; i<LOOP_NUM; i++)
    {
        printf("T%d:#\n", idx);
        memset(readBuf[idx], 0x55, BUF_SIZE);
        res = f_read(readBuf[idx], 1, BUF_SIZE, file);
        if(res != BUF_SIZE)
        {
            printf("T%d: read back size 0x%X != read size 0x%X \n", idx, res, BUF_SIZE);
            goto end;
        }
        diff = memcmp((void*)pattern[idx], (void*)readBuf[idx], BUF_SIZE);
        if(diff)
            printf("T%d: diff = %d \n", idx, diff);

        if(diff)
		{
			uint32_t j = 0, count=0;
            printf("T%d: i = %d \n", idx, i);
			for(j=0; j<BUF_SIZE; j++)
			{
				if(pattern[idx][j] != readBuf[idx][j])
                {
					printf("T%d: write buffer[%X] = %02X, read buffer1[%X] = %02X \n", idx, j, pattern[idx][j], j, readBuf[idx][j]);
                    //if(count++ > 50)
                    //    while(1);
                }
			}
			err();
		}
    }
    res = 0;
    printf("T%d: Compare Data End!!\n\n\n", idx);

    free(pattern[idx]);
    free(readBuf[idx]);

    usleep(500*1000);

end:
    if(file)
    {
        res = fclose(file);
        file = NULL;
    }
    return res;
}




extern F_DRIVER * msc_initfunc(unsigned long driver_param);

struct
{
    int mscIndex;   // 8*usbIndex + mscLun
    int usbIndex;   // usb0 or usb1
    int mscLun;     // lun number
    void* ctxt;     // context
    int type;       // MSC or UAS
} mscParams[16] =
{
    { 0, 0, 0, NULL, 0},
    { 1, 0, 1, NULL, 0},
    { 2, 0, 2, NULL, 0},
    { 3, 0, 3, NULL, 0},
    { 4, 0, 4, NULL, 0},
    { 5, 0, 5, NULL, 0},
    { 6, 0, 6, NULL, 0},
    { 7, 0, 7, NULL, 0},
    { 8, 1, 0, NULL, 0},
    { 9, 1, 1, NULL, 0},
    {10, 1, 2, NULL, 0},
    {11, 1, 3, NULL, 0},
    {12, 1, 4, NULL, 0},
    {13, 1, 5, NULL, 0},
    {14, 1, 6, NULL, 0},
    {15, 1, 7, NULL, 0}
};
static char name[16] = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P'};

static int loopcnt;


int TestFunc(MscLunStatus *mscStatus)
{
    int mscIndex;
    int res;

    f_init();
    f_enterFS();

    mscIndex = mscStatus->lun;
    mscParams[mscIndex].ctxt = mscStatus->ctxt;
    mscParams[mscIndex].type = mscStatus->type;

    do {
        res = f_initvolume(mscIndex, msc_initfunc, (unsigned long)&mscParams[mscIndex]);
        if (res)
        {
            printf(" T%d: initvolume fail! res=%d \n", mscIndex, res);
            f_delvolume(mscIndex);
            err();
        }
        printf(" T%d: initvolume ok! loopcnt = %d \n", mscIndex, ++loopcnt);

        sprintf(filePath[mscIndex] + 1, ":/msc_%d.dat", mscIndex);
        filePath[mscIndex][0] = name[mscIndex];
        printf(" file name: %s \n", filePath[mscIndex]);

        res = ReadWriteTest(mscIndex);
        if (res)
        {
            f_delvolume(mscIndex);
            err();
        }

        res = f_delvolume(mscIndex);
        if (res)
            printf(" delvolume fail! \n");

    } while (1);

end:
    return res;
}
