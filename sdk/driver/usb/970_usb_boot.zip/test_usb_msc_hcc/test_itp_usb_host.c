﻿/*
 * Copyright (c) 2011 ITE Tech. Inc. All Rights Reserved.
 */
/** @file
 * PAL USB Host related code.
 *
 * @author Irene Lin
 * @version 1.0
 */

typedef struct
{
    int     index;
    bool    connected;
    int     type;
    void*   ctxt;  /* usb device's context that currently connected */
} ITPUsb;


#include "test_itp_usb_msc.c"


static ITPUsb itpUsb[2] = {{USB0, false, 0, NULL}, {USB1, false, 0, NULL}};

static int _CheckUsbState(ITPUsb* itpusb)
{
    static USB_DEVICE_INFO device_info = {0};
    static int usb_state = 0;
    int res;

    res = mmpUsbExCheckDeviceState(itpusb->index, &usb_state, &device_info);
    if(!res)
    {
        if(USB_DEVICE_CONNECT(usb_state))
        {
            itpusb->type = device_info.type;
            itpusb->ctxt = device_info.ctxt;
            itpusb->connected = true;

            #if defined(CFG_UAS_ENABLE)
            UasConnect(itpusb);
            #endif

            #if defined(CFG_MSC_ENABLE)
            MscConnect(itpusb);
            #endif // CFG_MSC_ENABLE
        }
#if 0
        if(USB_DEVICE_DISCONNECT(usb_state))
        {
            #if defined(CFG_UAS_ENABLE)
            UasDisconnect(itpusb);
            #endif

            #if defined(CFG_MSC_ENABLE)
            MscDisconnect(itpusb);
            #endif // CFG_MSC_ENABLE

            itpusb->connected = false;
            itpusb->ctxt = NULL;
            itpusb->type = 0;
        }
#endif
    }

    return res;
}

static void* UsbHostDetectHandler(void* arg)
{
    while(1)
    {
    #if defined(CFG_USB0_ENABLE)
        if(_CheckUsbState(&itpUsb[USB0]))
            printf(" itp usb0 check state fail! \n");
    #endif

    #if defined(CFG_USB1_ENABLE)
        if(_CheckUsbState(&itpUsb[USB1]))
            printf(" itp usb1 check state fail! \n");
    #endif
        usleep(30*1000);
    }
}
