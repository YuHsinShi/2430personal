﻿#ifndef USB_PORT_H
#define USB_PORT_H



#ifdef __cplusplus
extern "C" {
#endif


#define MMP_TRUE        true
#define MMP_FALSE       false

#define MMP_NULL        NULL
#define MMP_INT         int
#define MMP_INT32       int
#define MMP_UINT32      uint32_t
#define MMP_UINT        uint32_t
#define MMP_UINT16      uint16_t
#define MMP_UINT8       uint8_t
#define MMP_ULONG       uint32_t
#define MMP_BOOL        bool
#define MMP_INLINE      inline


/*
 * for sempahore
 */
#if 1 // for usb boot
#define SYS_WaitSemaphore               
#define SYS_ReleaseSemaphore            
#else
sem_t* usb_create_sem(int cnt);
#define MMP_MUTEX                       sem_t*
#define SYS_CreateSemaphore(cnt,c)      usb_create_sem(cnt)  
#define SYS_WaitSemaphore               sem_wait
#define SYS_ReleaseSemaphore            sem_post
#define SYS_DeleteSemaphore(a)			do { sem_destroy(a); free(a); } while(0)
#endif // for usb boot



#define MMP_Sleep(x)                    usleep(x*1000)


#ifdef __cplusplus
}
#endif

#endif


