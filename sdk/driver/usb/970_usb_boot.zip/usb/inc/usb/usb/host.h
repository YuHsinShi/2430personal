﻿#ifndef USBEX_HOST_H
#define USBEX_HOST_H


#include "ite/ite_usbex.h"
#include "usb/usb/usbex_error.h"
#include "usb/usb/usb.h"
#include "usb/usb/hcd.h"
//#include "usb/usb/quirks.h"  // for usb boot
#include "usb/usb/hcd/ehci.h"


#endif

