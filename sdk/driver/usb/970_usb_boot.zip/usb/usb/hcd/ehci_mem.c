﻿/*
 * Copyright (c) 2008 SMedia Technology Corp. All Rights Reserved.
 */
/** @file
 * ehci memory related. This file is part of ehci-hcd.c
 *
 * @author Irene Lin
 */

#define EHCI_QH_ALIGN          32
#define EHCI_QH_SIZE           ((sizeof(struct ehci_qh) + (EHCI_QH_ALIGN-1)) & ~(EHCI_QH_ALIGN-1))
#define EHCI_QH_TOTAL_SIZE     (EHCI_QH_NUM*EHCI_QH_SIZE)

#define EHCI_QTD_ALIGN         32
#define EHCI_QTD_SIZE          ((sizeof(struct ehci_qtd) + (EHCI_QTD_ALIGN-1)) & ~(EHCI_QTD_ALIGN-1))
#define EHCI_QTD_TOTAL_SIZE    (EHCI_QTD_NUM*EHCI_QTD_SIZE)

static uint8_t qh_pool[2][EHCI_QH_TOTAL_SIZE] __attribute__ ((aligned(32)));
static uint8_t qtd_pool[2][EHCI_QTD_TOTAL_SIZE] __attribute__ ((aligned(32)));

static inline void ehci_qtd_init(struct ehci_hcd *ehci, struct ehci_qtd *qtd,
                  dma_addr_t addr, uint32_t buf_index)
{
    memset (qtd, 0, sizeof *qtd);
    qtd->qtd_dma= addr;
    qtd->hw_token = cpu_to_le32 (QTD_STS_HALT);
    qtd->hw_next = EHCI_LIST_END(ehci);
    qtd->hw_alt_next = EHCI_LIST_END(ehci);
    INIT_LIST_HEAD (&qtd->qtd_list);
    qtd->buf_index = buf_index;
}

static struct ehci_qtd* ehci_qtd_alloc(struct ehci_hcd* ehci)
{
    struct ehci_qtd* qtd = NULL;
    uint32_t i=0;

    ithEnterCritical();
    for(i=0; i<EHCI_QTD_NUM; i++)
    {
        if(ehci->qtd_manage[i] == EHCI_MEM_FREE)
        {
            ehci->qtd_manage[i] = EHCI_MEM_USED;
            qtd = (struct ehci_qtd*)(ehci->qtd_pool+i*EHCI_QTD_SIZE);
            break;
        }
    }

    if(qtd)
        ehci_qtd_init(ehci, qtd, (dma_addr_t)qtd, i);
    //ithPrintf(" alloc qtd: %p \n", qtd);
    ithExitCritical();

    return qtd;
}

static void ehci_qtd_free(struct ehci_hcd* ehci, struct ehci_qtd* qtd)
{
    uint32_t index = 0;

    ithEnterCritical();
    //ithPrintf(" free qtd: %p \n", qtd);

    index = qtd->buf_index;
    if(ehci->qtd_manage[index] == EHCI_MEM_FREE)
        LOG_ERROR " qtd double free!!! index = %d (%p) \n", index, qtd LOG_END

    ehci->qtd_manage[index] = EHCI_MEM_FREE;

    ithExitCritical();
}

static void qh_destroy(struct ehci_qh *qh)
{
    struct ehci_hcd *ehci = qh->ehci;
	
    if(qh==NULL) 
		return;

    ithEnterCritical();
    //ithPrintf(" free qh: %p \n", qh);

    if(!list_empty(&qh->qtd_list) || qh->qh_next.ptr)
    {
        LOG_ERROR " unused qh not empty! \n" LOG_END
        while(1);
    }
    if(qh->dummy)
        ehci_qtd_free(ehci, qh->dummy);

    if(ehci->qh_manage[qh->buf_index] == EHCI_MEM_FREE)
        LOG_ERROR " qh double free!!! index = %d \n", qh->buf_index LOG_END

    ehci->qh_manage[qh->buf_index] = EHCI_MEM_FREE;

    ithExitCritical();
}

static struct ehci_qh* ehci_qh_alloc(struct ehci_hcd* ehci)
{
    struct ehci_qh* qh = NULL;
    uint32_t i=0;

    ithEnterCritical();

    for(i=0; i<EHCI_QH_NUM; i++)
    {
        if(ehci->qh_manage[i] == EHCI_MEM_FREE)
        {
            ehci->qh_manage[i] = EHCI_MEM_USED;
            qh = (struct ehci_qh*)(ehci->qh_pool+i*EHCI_QH_SIZE);
            break;
        }
    }

    if(qh)
    {
        memset((void*)qh, 0x0, sizeof(*qh));
        qh->ehci = ehci;
        qh->refcount = 1;
        qh->qh_dma= (dma_addr_t)qh;
        INIT_LIST_HEAD(&qh->qtd_list);
        qh->buf_index = i;

        qh->dummy = ehci_qtd_alloc(ehci);
        if(qh->dummy == NULL)
        {
            LOG_ERROR " no dummy qtd \n" LOG_END
            ehci->qh_manage[i] = EHCI_MEM_FREE;
            qh = NULL;
        }
    //ithPrintf(" alloc qh: %p \n", qh);
    }

    ithExitCritical();

    return qh;
}

static struct ehci_qh* qh_get(struct ehci_qh* qh)
{
    ithEnterCritical();

    qh->refcount++;
    //LOG_DEBUG " qh 0x%08X refcount++ %d \n", qh, qh->refcount LOG_END

    ithExitCritical();

    return qh;
}

static void qh_put(struct ehci_qh* qh)
{
    ithEnterCritical();

    qh->refcount--;
    //LOG_DEBUG " qh 0x%08X refcount-- %d \n", qh, qh->refcount LOG_END

    if(qh->refcount==0)
        qh_destroy(qh);

    ithExitCritical();
}


static int ehci_mem_init(struct ehci_hcd *ehci)
{
    int result = 0;

    /** NOTE!!! These memory will never be released! here I will align the pool base  */

    /* QH for control/bulk/intr transfers */
    ehci->qh_pool = qh_pool[ehci_to_hcd(ehci)->index];
    if(!ehci->qh_pool)
    {
        result = ERROR_USB_ALLOC_QH_FAIL;
        goto end;
    }

    /* QTDs for control/bulk/intr transfers */
    ehci->qtd_pool = qtd_pool[ehci_to_hcd(ehci)->index];
    if(!ehci->qtd_pool)
    {
        result = ERROR_USB_ALLOC_QTD_FAIL;
        goto end;
    }

    ehci->async = ehci_qh_alloc(ehci);
    if(!ehci->async)
    {
        result = ERROR_USB_ALLOC_DYMMY_QH_FAIL;
        goto end;
    }

end:
    if(result)
        LOG_ERROR " ehci_mem_init() rc 0x%08X, driver index 0x%08X \n", result, ehci_to_hcd(ehci)->index LOG_END
    return result;
}


