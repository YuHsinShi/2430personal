﻿/*
 * Copyright (c) 2008 SMedia Technology Corp. All Rights Reserved.
 */
/** @file
 * EHCI hc_driver implementation.
 *
 * @author Irene Lin
 */
//=============================================================================
//                              Include Files
//=============================================================================
#include "usb/config.h"
#include "usb/usb/host.h"


//=============================================================================
//                              Global Data Definition
//=============================================================================

#if (CFG_CHIP_FAMILY == 9070)
ITHUsbInterface g_usb_intf = ITH_USB_AMBA;
#else
ITHUsbInterface g_usb_intf = ITH_USB_WRAP;
#endif

static struct usb_hcd* otg_hcd;


//sem_t   isr_event;  // usb boot

//=============================================================================
//                              Public Function Definition
//=============================================================================

#if ((CFG_CHIP_FAMILY == 9070) || (CFG_CHIP_FAMILY == 9910))
static int usb_checkPhyClock(int usb_enable)
{
    uint32_t  usb0_en = usb_enable & (1 << 0);
    uint32_t  usb1_en = usb_enable & (1 << 1);
    uint16_t value = 0;
    uint32_t cnt = 1000;
    uint32_t step;

    if (usb0_en)
    {
        step = 1;
        while (cnt)
        {
            value = ithReadRegH(0x908);
            if (step == 1)
            {
                if (value & 0x4000)
                    step = 2;
            }
            else if (step == 2)
            {
                if (!(value & 0x4000))
                    step = 3;
            }
            else if (step == 3)
            {
                if (value & 0x4000)
                    break;
            }
            cnt--;
            usleep(50);
        }
        if (cnt == 0)  { printf(" USB0 controller's input clock not work!!! \n\n");  return -1; }
    }
    if (usb1_en)
    {
        cnt = 1000;
        step = 1;
        while (cnt)
        {
            value = ithReadRegH(0x910);
            if (step == 1)
            {
                if (value & 0x4000)
                    step = 2;
            }
            else if (step == 2)
            {
                if (!(value & 0x4000))
                    step = 3;
            }
            else if (step == 3)
            {
                if (value & 0x4000)
                    break;
            }
            cnt--;
            usleep(50);
        }
        if (cnt == 0)  { printf(" USB1 controller's input clock not work!!! \n\n");  return -1; }
    }

    return 0;
}
#else
static int usb_checkPhyClock(int usb_enable)
{
    uint32_t  usb0_en = usb_enable & (1 << 0);
    uint32_t  usb1_en = usb_enable & (1 << 1);
	uint32_t cnt;

	if (usb0_en)
	{
        cnt = 1000;
        while (cnt)
        {
        #if (CFG_CHIP_FAMILY == 9850)
            if (!(ithReadRegH(0x908) & 0x1000))
        #else
            if (!(ithReadRegA(ITH_USB0_BASE + 0x2C) & 0x1))
        #endif
        	{
				cnt--;
				usleep(50);
        	}
			else
				break;
        }
        if (cnt == 0)  { printf(" USB0 controller's input clock not work!!! \n\n");  return -1; }
	}
	if (usb1_en)
	{
        cnt = 1000;
        while (cnt)
        {
        #if (CFG_CHIP_FAMILY == 9850)
            if (!(ithReadRegH(0x910) & 0x1000))
        #else
            if (!(ithReadRegA(ITH_USB1_BASE + 0x2C) & 0x1))
        #endif
        	{
				cnt--;
				usleep(50);
        	}
			else
				break;
        }
        if (cnt == 0)  { printf(" USB1 controller's input clock not work!!! \n\n");  return -1; }
	}

	return 0;
}
#endif


int mmpUsbExInitialize(int usb_enable)
{
    int result = 0;
    uint16_t value = 0;
    uint32_t usb0 = 0x0;
    uint32_t usb1 = 0x1;
    uint16_t packageType = 0;
    uint32_t  usb0_en = usb_enable & (1 << 0);
    uint32_t  usb1_en = usb_enable & (1 << 1);

    if(!usb_enable)
    {
        result = -1;
        goto end;
    }

    if(usb0_en)
        ithUsbPhyPowerOn(ITH_USB0);
    if(usb1_en)
        ithUsbPhyPowerOn(ITH_USB1);
    usleep(10*1000);

    if (result = usb_checkPhyClock(usb_enable))
        goto end;

    ithUsbReset();
    ithUsbInterfaceSel(g_usb_intf);


    #if defined(RUN_FPGA)
    mUsbTstHalfSpeedEn();  
    //ithWriteRegMaskA((ITH_USB0_BASE|0x100), 0x2, 0x2);
    #endif

    /** usb host controller basic init */
    if(usb0_en)
    {
        result = ehci_hcd_init(usb0);
        if(result)
            goto end;
    }
    if(usb1_en)
    {
        result = ehci_hcd_init(usb1);
        if(result)
            goto end;
    }

end:
    if(result)
        LOG_ERROR " mmpUsbExInitialize() return error code 0x%08X \n", result LOG_END
    return result;
}

uint32_t mmpUsbExCheckDeviceState(int usb, int* state, USB_DEVICE_INFO* device_info)
{
    int result = 0;
    uint32_t temp = 0;
    struct ehci_hcd* ehci = NULL;
    struct usb_device* dev = NULL;
    struct usb_hcd* hcd = NULL;
    bool exit = (usb & 0x10) ? true : false; /** for suspend use */
    usb &= ~0x10;

    (*state) = 0;

    if(usb == USB0)
        hcd = hcd0;
    else if(usb == USB1)
        hcd = hcd1;

    if(!hcd)
        goto end;

    ehci = hcd_to_ehci(hcd);
    temp = ithReadRegA(ehci->regs.port_status[0]);

    //if(temp & PORT_CONNECT) /** device present */
    if((temp & PORT_CONNECT) && (exit==false)) /** device present */
    {
        if(!hcd->connect)
        {
            result = ehci_start(hcd, &dev);
            if(result)
                goto end;

                (*state) = USB_DEVICE_STATE_CONNECT;
            memcpy((void*)device_info, &dev->device_info, sizeof(USB_DEVICE_INFO));
        }
    }
    else
    {
        if(hcd->connect)
        {
            (*state) = USB_DEVICE_STATE_DISCONNECT;
            device_info->ctxt = NULL;
            device_info->type = hcd->driver->stop(hcd);
        }
    }

end:
    if(result)
        LOG_ERROR " mmpUsbExCheckDeviceState() return error code 0x%08X \n", ((result<0)? (-result) : result) LOG_END
    return result;
}

int iteUsbExIsPortConnect(int usb)
{
    int connect = 0;
    struct usb_hcd* hcd = NULL;
    struct ehci_hcd* ehci = NULL;

    if(usb == USB0)
        hcd = hcd0;
    else if(usb == USB1)
        hcd = hcd1;

    if(!hcd)
        goto end;

    ehci = hcd_to_ehci(hcd);
    connect = (ithReadRegA(ehci->regs.port_status[0]) & PORT_CONNECT) ? 1 : 0;

end:
    return connect;
}


